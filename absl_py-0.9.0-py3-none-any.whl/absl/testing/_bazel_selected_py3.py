# The presence of this module means, at build time, Bazel used Python 3
# when resolving select() calls based on Python version.
